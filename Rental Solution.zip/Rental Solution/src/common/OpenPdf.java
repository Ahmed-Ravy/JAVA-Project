/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package common;

import dao.InventoryUtils;
import java.io.File;
import javax.swing.JOptionPane;

/**
 *
 * @author Hp Pc
 */
import javax.swing.JOptionPane;
import java.io.File;

public class OpenPdf {

    public static void OpenById(String id) {

        try {
            String filePath = InventoryUtils.billPath + id + ".pdf";
            File file = new File(filePath);

            if (file.exists()) {
                // Using cmd /c start for better reliability
                Process p = Runtime.getRuntime().exec("cmd /c start \"\" \"" + filePath + "\"");
            } else {
                JOptionPane.showMessageDialog(null, "File does not exist.");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
}

