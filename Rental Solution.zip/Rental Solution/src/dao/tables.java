package dao;

import java.sql.*;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.Statement;

/**
 *
 * @author MTBD
 */
public class tables {

    public static void main(String[] args) {
        try {
            Connection con = conn.getCon();
            Statement st = con.createStatement();
            //st.executeUpdate("create table user (user_id INT NOT NULL AUTO_INCREMENT , username varchar(50),email varchar(200),mobileNumber varchar(50),password varchar(200),address varchar(200),status varchar(50), PRIMARY KEY (user_id))");
            //st.executeUpdate("insert into bal(name)values ('ravy')");status varchar(50),
            //st.executeUpdate("create table user (user_id int AUTO_INCREMENT primary key,userRole varchar(50),username varchar(50),email varchar(200),mobileNumber varchar(50),password varchar(200),address varchar(200),status varchar(50))");
            //st.executeUpdate("insert into user (userRole,username,email,mobileNumber,password,address,status) values('Super Admin','Ravy','superadmin@gmail.com','01920755229','1234','Dhaka','Active')");
            //st.executeUpdate("create table category (category_id int AUTO_INCREMENT primary key, name varchar(200))" );
            //st.executeUpdate("create table product (product_id int AUTO_INCREMENT primary key, name varchar(200),quantity int, price int, description varchar(500), category_fk int)" );
            //st.executeUpdate("create table customer (customer_id int AUTO_INCREMENT primary key,name varchar(200), mobileNumber varchar(50), email varchar(200)  )");
              st.executeUpdate("create table orderDetail (order_pk int AUTO_INCREMENT primary key, orderId varchar(200), customer_fk int, orderDate varchar (200), totalPaid int) ");
            JOptionPane.showMessageDialog(null, "Table Created Successfully");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }
}
